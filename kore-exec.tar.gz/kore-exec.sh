#!/bin/sh
exec kore-exec \
    vdefinition.kore \
    --output result.kore \
    --module SRW3LIN-SYMB \
    --strategy all \
    --max-counterexamples 1 \
    --smt-timeout 125 \
    --smt-retry-limit 3 \
    --smt-reset-interval 100 \
    --smt z3 \
    --log-level \
    warning \
    --enable-log-timestamps \
    --prove spec.kore \
    --spec-module SRW3LIN-SYMB-STEP \
    --graph-search breadth-first \
     \
     \
     \
     \
     \
     \
    "$@"
